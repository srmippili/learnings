package me.rama.spring.redis.streams.producer;


import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.github.javafaker.Faker;

import me.rama.spring.redis.streams.dto.Category;
import me.rama.spring.redis.streams.dto.Entry;
import me.rama.spring.redis.streams.dto.Product;

@Service
public class EntryRepository {
	
	private static final Double[] oddsArray = { 210.17, 1.38, 2.56, 4.3, 6.8, 100.8, 0.54, 10.8, 0.15 };

    private static final List<Product> PRODUCTS = Stream.of(
            // appliances
            new Product("oven", 500.00, Category.APPLIANCES),
            new Product("dishwasher", 125.00, Category.APPLIANCES),
            new Product("heater", 65.00, Category.APPLIANCES),
            new Product("vacuum cleaner", 48.00, Category.APPLIANCES),
            new Product("refrigerator", 1200.00, Category.APPLIANCES),
            // books
            new Product("how to win friends and influence", 13.00, Category.BOOKS),
            new Product("ds and algorithms", 70.00, Category.BOOKS),
            new Product("effective java", 41.00, Category.BOOKS),
            new Product("clean architecture", 32.00, Category.BOOKS),
            new Product("microservices", 16.00, Category.BOOKS),
            // cosmetics
            new Product("brush", 9.50, Category.COSMETICS),
            new Product("face wash", 13.00, Category.COSMETICS),
            new Product("makeup mirror", 17.50, Category.COSMETICS),
            // electronics
            new Product("sony 4k tv", 999.25, Category.ELECTRONICS),
            new Product("headphone", 133.25, Category.ELECTRONICS),
            new Product("macbook", 2517.25, Category.ELECTRONICS),
            new Product("speaker", 65.25, Category.ELECTRONICS),
            // outdoor
            new Product("plants", 9.75, Category.OUTDOOR),
            new Product("power tools", 73.50, Category.OUTDOOR),
            new Product("pools", 111.75, Category.OUTDOOR)
    ).collect(Collectors.toList());

    public Product getRandomProduct(){
        int random = ThreadLocalRandom.current().nextInt(0, 20);
        return PRODUCTS.get(random);
    }
    
    
    public Entry getRandomEntry() {
    	Faker faker = new Faker(new Random());
		String userName = faker.name().username();
		Integer overAllProgressPercentage = (new Random()).nextInt(100);
		Entry entry = new Entry();
		entry.setUserId(userName);
		entry.setOverAllProgressPercentage(overAllProgressPercentage);
		entry.setContest("CONTEST");
		Integer oddIndex = (new Random()).nextInt(oddsArray.length);
		entry.setOdds(oddsArray[oddIndex]);
		return entry;
    }
    

}
