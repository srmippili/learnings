package me.rama.spring.redis.streams.consumer;

import java.net.InetAddress;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.connection.stream.ObjectRecord;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.stream.StreamListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import me.rama.spring.redis.streams.dto.Entry;

@Service
@ConditionalOnProperty(name = "app.role", havingValue = "consumer")
@Log4j2
public class EntryConsumer implements StreamListener<String, ObjectRecord<String, Entry>> {

	private AtomicInteger atomicInteger = new AtomicInteger(0);

	@Autowired
	private ReactiveRedisTemplate<String, String> redisTemplate;

	@Override
	@SneakyThrows
	public void onMessage(ObjectRecord<String, Entry> record) {
		log.info(InetAddress.getLocalHost().getHostName() + " - consumed :" + record.getValue());
		this.redisTemplate.opsForZSet()
				.add("CONTEST", record.getValue().toString(), record.getValue().getOverAllProgressPercentage())
				.subscribe();
		atomicInteger.incrementAndGet();
	}

	@Scheduled(fixedRate = 10000)
	public void showPublishedEventsSoFar() {
		log.info("Total Consumed :: " + atomicInteger.get());
	}

}
