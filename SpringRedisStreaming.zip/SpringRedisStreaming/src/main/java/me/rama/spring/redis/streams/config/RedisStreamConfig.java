package me.rama.spring.redis.streams.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.stream.Consumer;
import org.springframework.data.redis.connection.stream.ObjectRecord;
import org.springframework.data.redis.connection.stream.ReadOffset;
import org.springframework.data.redis.connection.stream.StreamOffset;
import org.springframework.data.redis.stream.StreamListener;
import org.springframework.data.redis.stream.StreamMessageListenerContainer;
import org.springframework.data.redis.stream.StreamMessageListenerContainer.StreamMessageListenerContainerOptions;
import org.springframework.data.redis.stream.Subscription;

import me.rama.spring.redis.streams.dto.Entry;

@Configuration
@ConditionalOnProperty(name = "app.role", havingValue = "consumer")
public class RedisStreamConfig {

	@Value("${stream.key}")
	private String streamKey;

	@Bean
	public Subscription subscription(RedisConnectionFactory redisConnectionFactory,
			StreamListener<String, ObjectRecord<String, Entry>> streamListener) throws UnknownHostException {
		StreamMessageListenerContainerOptions<String, ObjectRecord<String, Entry>> options = StreamMessageListenerContainer.StreamMessageListenerContainerOptions
				.builder().pollTimeout(Duration.ofSeconds(1)).targetType(Entry.class).build();
		StreamMessageListenerContainer<String, ObjectRecord<String, Entry>> listenerContainer = StreamMessageListenerContainer
				.create(redisConnectionFactory, options);
		Subscription subscription = listenerContainer.receiveAutoAck(
				Consumer.from(streamKey, InetAddress.getLocalHost().getHostName()),
				StreamOffset.create(streamKey, ReadOffset.lastConsumed()), streamListener);
		listenerContainer.start();
		return subscription;
	}

}
