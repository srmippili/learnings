/**
 * 
 */
package me.rama.spring.redis.streams.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author RPolepalli
 *
 */
@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Entry implements Serializable, Comparable<Entry>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String userId;
	private Integer overAllProgressPercentage;
	private Long rank;
	private String contest;
	
	private double odds;
	
	@Override
	public int compareTo(Entry o) {
		int val = 0;
		if(overAllProgressPercentage < o.getOverAllProgressPercentage())
			val = 1;
		if(overAllProgressPercentage > o.getOverAllProgressPercentage())
			val = -1;
		if(overAllProgressPercentage == o.getOverAllProgressPercentage())
			val = 0;
		
		return val;
	}
}
