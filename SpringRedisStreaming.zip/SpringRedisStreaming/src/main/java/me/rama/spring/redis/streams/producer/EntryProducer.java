package me.rama.spring.redis.streams.producer;

import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.connection.stream.ObjectRecord;
import org.springframework.data.redis.connection.stream.StreamRecords;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.extern.log4j.Log4j2;
import me.rama.spring.redis.streams.dto.Entry;

@Service
@ConditionalOnProperty(name = "app.role", havingValue = "producer")
@Log4j2
public class EntryProducer {

	private AtomicInteger atomicInteger = new AtomicInteger(0);

	@Value("${stream.key}")
	private String streamKey;

	@Autowired
	private EntryRepository repository;

	@Autowired
	private ReactiveRedisTemplate<String, String> redisTemplate;

	@Scheduled(fixedRateString = "${publish.rate}")
	public void publishEvent() {
		Entry entry = this.repository.getRandomEntry();
		ObjectRecord<String, Entry> record = StreamRecords.newRecord().ofObject(entry).withStreamKey(streamKey);
		this.redisTemplate.opsForStream().add(record).subscribe(log::info);
		atomicInteger.incrementAndGet();
	}

	@Scheduled(fixedRate = 10000)
	public void showPublishedEventsSoFar() {
		log.info("Total Events :: " + atomicInteger.get());
	}

}
