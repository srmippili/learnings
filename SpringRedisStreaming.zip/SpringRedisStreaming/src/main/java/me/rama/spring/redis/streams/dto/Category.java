package me.rama.spring.redis.streams.dto;

public enum Category {
	APPLIANCES, BOOKS, COSMETICS, ELECTRONICS, OUTDOOR;
}
