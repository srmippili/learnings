package com.example.demo.client.webClient;

import java.net.URI;

import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.demo.dto.StudentVO;

import reactor.core.publisher.Mono;

@Service
public class WebClientCall {

	public Mono<StudentVO> getStudentInfo() {
		WebClient webClient = WebClient.create();
		ClientResponse res = webClient.method(HttpMethod.GET).uri(URI.create("http://localhost:9095/getStudentInfo"))
				.accept(MediaType.APPLICATION_JSON).exchange().block();
		return res.bodyToMono(StudentVO.class);
	}

}
