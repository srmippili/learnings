package com.example.demo.client.restTemplate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.demo.dto.StudentVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Component
public class RestTemplateCall {

	private @Autowired RestTemplate restTemplate;

	public ResponseEntity<StudentVO> getStudentInfo() throws JsonMappingException, JsonProcessingException {
		String requestUri = UriComponentsBuilder.fromHttpUrl("http://localhost:9095/getStudentInfo/").toUriString();
		return restTemplate.getForEntity(requestUri, StudentVO.class);
	}

}
