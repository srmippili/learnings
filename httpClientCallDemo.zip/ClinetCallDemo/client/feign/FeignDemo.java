package com.example.demo.client.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.dto.StudentVO;

@FeignClient(name = "test", url = "http://localhost:9095/", configuration = BppFeignConfig.class)
public interface FeignDemo {

  @GetMapping("getStudentInfo")
  StudentVO getSutdentInfo();

}
