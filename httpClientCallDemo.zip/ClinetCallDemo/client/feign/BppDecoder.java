package com.example.demo.client.feign;

import java.io.IOException;
import java.lang.reflect.Type;

import com.fasterxml.jackson.databind.ObjectMapper;

import feign.Response;
import feign.codec.Decoder;

public class BppDecoder implements Decoder {
	private final ObjectMapper feignObjectMapper;

	public BppDecoder(ObjectMapper feignObjectMapper) {
		super();
		this.feignObjectMapper = feignObjectMapper;
	}

	@Override
	public Object decode(Response response, Type type) throws IOException {
		if (type instanceof Class) {
			return feignObjectMapper.readValue(response.body().asInputStream(), (Class<?>) type);
		}
		return new Decoder.Default().decode(response, type);
	}

}
