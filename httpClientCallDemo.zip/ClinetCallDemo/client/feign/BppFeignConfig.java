package com.example.demo.client.feign;

import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.codec.Decoder;

public class BppFeignConfig {

	@Bean
	public Decoder decoder() {
		return new BppDecoder(feignObjectMapper());
	}


	private ObjectMapper feignObjectMapper() {
		return new ObjectMapper().disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	}
}
