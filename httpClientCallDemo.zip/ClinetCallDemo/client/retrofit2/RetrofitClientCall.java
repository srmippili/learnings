package com.example.demo.client.retrofit2;

import java.io.IOException;
import java.util.function.Predicate;
import java.util.function.Supplier;

import org.springframework.stereotype.Component;

import com.example.demo.dto.ErrorBody;
import com.example.demo.dto.GeneralResponse;
import com.example.demo.dto.StudentVO;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

@Component
public class RetrofitClientCall {
	
	private Endpoint endpoint;

	public RetrofitClientCall() {
		endpoint = new Retrofit.Builder()
				.baseUrl("http://localhost:9095/")
				.addConverterFactory(JacksonConverterFactory.create(this.getMapper()))
				.build()
				.create(Endpoint.class);

	}

	public GeneralResponse<StudentVO> getStudentInfo() {
		return new BaseRequestExecutor<StudentVO>().request(() -> endpoint.getStudentInfo())
				.errorCondition(response -> response.errorBody() != null)
				.errorLog(() -> "Error during processing placeBet").execute();
	}

	ObjectMapper getMapper() {
		return new ObjectMapper().findAndRegisterModules()
				.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
				.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
				.setSerializationInclusion(Include.NON_NULL);
	}

	public class BaseRequestExecutor<T> {
		private Supplier<Call<T>> request;
		private Predicate<Response<T>> errorCondition;
		private Supplier<String> errorLog;

		public BaseRequestExecutor<T> request(Supplier<Call<T>> request) {
			this.request = request;
			return this;
		}

		BaseRequestExecutor<T> errorCondition(Predicate<Response<T>> errorCondition) {
			this.errorCondition = errorCondition;
			return this;
		}

		BaseRequestExecutor<T> errorLog(Supplier<String> errorLog) {
			this.errorLog = errorLog;
			return this;
		}

		GeneralResponse<T> execute() {
			try {
				Response<T> betsResponse = request.get().execute();
				ErrorBody errorBody = null;
				if (errorCondition.test(betsResponse)) {
					errorBody = this.getMapperCustom().readValue(betsResponse.errorBody().string(), ErrorBody.class);
				}
				return new GeneralResponse<>(betsResponse.body(), errorBody);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		ObjectMapper getMapperCustom() {
			return new ObjectMapper().findAndRegisterModules()
					.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.setSerializationInclusion(Include.NON_NULL); // FIXME: use NON_EMPTY
		}
	}
}
