package com.example.demo.client.retrofit2;

import com.example.demo.dto.StudentVO;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public interface Endpoint {

	@GET("getStudentInfo")
	@Headers("Content-Type: application/json")
	Call<StudentVO> getStudentInfo();
}
