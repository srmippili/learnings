package com.example.demo.dto;

public class StudentVO {

	private Long roll;
	private String name;
	private String address;
	//private String mobileNo;

	public StudentVO() {
	}

	public Long getRoll() {
		return roll;
	}

	public void setRoll(Long roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	/*
	 * public String getMobileNo() { return mobileNo; }
	 * 
	 * public void setMobileNo(String mobileNo) { this.mobileNo = mobileNo; }
	 */
	
}
