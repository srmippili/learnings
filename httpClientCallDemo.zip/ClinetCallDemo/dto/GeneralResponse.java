package com.example.demo.dto;

/** Created by llegkyy on 26.10.17. */
public class GeneralResponse<T> {
  private T body;
  private ErrorBody errorBody;

  public GeneralResponse(T body, ErrorBody errorBody) {
    this.body = body;
    this.errorBody = errorBody;
  }

  public T getBody() {

    return body;
  }

  public void setBody(T body) {
    this.body = body;
  }

  public ErrorBody getErrorBody() {
    return errorBody;
  }

  public void setErrorBody(ErrorBody errorBody) {
    this.errorBody = errorBody;
  }
}
