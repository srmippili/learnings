package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.client.feign.FeignDemo;
import com.example.demo.client.restTemplate.RestTemplateCall;
import com.example.demo.client.retrofit2.RetrofitClientCall;
import com.example.demo.client.webClient.WebClientCall;
import com.example.demo.dto.StudentVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import reactor.core.publisher.Mono;

@RestController
public class DemoController {
	
	@Autowired WebClientCall webClientCall;
	
	@Autowired RetrofitClientCall retrofitClientCall;
	
	@Autowired FeignDemo feignDemo;
	
	@Autowired RestTemplateCall restTemplateCall;
	
	@GetMapping(value = "/getStudentMono")
	public Mono<StudentVO> getStudentInfo(){
		return webClientCall.getStudentInfo();
	}
	
	@GetMapping(value = "/getStudentRetrofit")
	public StudentVO getStudentRetro(){
		return retrofitClientCall.getStudentInfo().getBody();
	}
	
	@GetMapping(value = "/getStudentFeign")
	public StudentVO getStudentFeign(){
		return feignDemo.getSutdentInfo();
	}
	@GetMapping(value = "/getStudentRestTemplate")
	public ResponseEntity<StudentVO> getStudentRestTem() throws JsonMappingException, JsonProcessingException{
		return restTemplateCall.getStudentInfo();
	}
}
